<?php
include 'header.php';
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['product_name'];
    $price = $_POST['product_price'];
    $quantity = $_POST['quantity'];
    $category = $_POST['category_id'];
    $desc = $_POST['description'];

    // Auto-generate product_id
    $result = $conn->query("SELECT product_id FROM products ORDER BY product_id DESC LIMIT 1");
    $lastId = ($result->num_rows > 0) ? $result->fetch_assoc()['product_id'] : "P000";
    $newId = "P" . str_pad((intval(substr($lastId, 1)) + 1), 3, "0", STR_PAD_LEFT);

    // Upload image
    $image = $_FILES['image']['name'];
    $target = "image/" . basename($image);
    move_uploaded_file($_FILES['image']['tmp_name'], $target);

    // Insert product
    $stmt = $conn->prepare("INSERT INTO products (product_id, product_name, product_price, quantity, category_id, description, image)
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdisss", $newId, $name, $price, $quantity, $category, $desc, $image);
    $stmt->execute();

    header("Location: admin_page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Product</title>
    <link rel="stylesheet" href="admin_styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<h2>Add New Product</h2>
<form method="post" enctype="multipart/form-data">
    <div>
        <label>Name:</label>
        <input type="text" name="product_name" required class="form-control">
    </div>

    <div>
        <label>Price:</label>
        <input type="number" step="0.01" name="product_price" required class="form-control">
    </div>

    <div>
        <label>Quantity:</label>
        <input type="number" name="quantity" required class="form-control">
    </div>

    <div>
        <label>Category:</label>
        <select name="category_id" class="form-control">
            <option value="graduation cap">Graduation Cap</option>
            <option value="graduation hood">Graduation Hood</option>
            <option value="graduation set">Graduation Set</option>
            <option value="other">Other</option>
        </select>
    </div>

    <div>
        <label>Description:</label>
        <textarea name="description" class="form-control" required></textarea>
    </div>

    <div>
        <label>Image:</label>
        <input type="file" name="image" required class="form-control">
    </div>
    <div class="add-btn">
        <button class="btn btn-primary">Add Product</button>
    </div>
    
</form>

<?php include 'footer.php'; ?>
</body>
</html>
