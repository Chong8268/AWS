<?php
include 'header.php';
include 'db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: login.php");
    exit();
}

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
    $new_user_id = trim($_POST["username"]);
    $gender = $_POST["gender"];
    $phone = preg_replace('/\D/', '', $_POST["phone"]);
    $address = trim($_POST["address"]);
    $current_password_input = $_POST["current_password"];
    $change_password = isset($_POST["change_password"]);
    $new_password = $_POST["new_password"] ?? '';

    $check_stmt = $conn->prepare("SELECT password FROM users WHERE user_id = ?");
    $check_stmt->bind_param("s", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result()->fetch_assoc();
    $current_password_db = $check_result['password'];

    if ($current_password_input !== $current_password_db) {
        $error = "Incorrect current password.";
    } else {
        if ($change_password && empty($new_password)) {
            $error = "Please enter a new password or uncheck 'Change Password'.";
        } else {
            if ($change_password) {
                $update_sql = "UPDATE users SET user_id = ?, gender = ?, phone = ?, shipping_address = ?, password = ? WHERE user_id = ?";
                $stmt = $conn->prepare($update_sql);
                $stmt->bind_param("ssssss", $new_user_id, $gender, $phone, $address, $new_password, $user_id);
            } else {
                $update_sql = "UPDATE users SET user_id = ?, gender = ?, phone = ?, shipping_address = ? WHERE user_id = ?";
                $stmt = $conn->prepare($update_sql);
                $stmt->bind_param("sssss", $new_user_id, $gender, $phone, $address, $user_id);
            }

            if ($stmt->execute()) {
                $_SESSION['user_id'] = $new_user_id;
                $user_id = $new_user_id;
                $success = "Profile updated successfully!";
            } else {
                $error = "Update failed.";
            }
        }
    }
}

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Fetch purchase history
$history_sql = "
    SELECT h.history_id, h.history_product_quantity, p.product_name, p.product_price 
    FROM history h
    JOIN products p ON h.history_product_id = p.product_id
    WHERE h.user_id = ?
    ORDER BY h.history_id DESC";
$stmt = $conn->prepare($history_sql);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$history_result = $stmt->get_result();

$history_data = [];
while ($row = $history_result->fetch_assoc()) {
    $history_data[$row['history_id']][] = $row;
}

// Handle profile deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_profile"])) {
    $delete_stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
    $delete_stmt->bind_param("s", $user_id);
    if ($delete_stmt->execute()) {
        session_destroy();
        header("Location: login.php?msg=Profile deleted");
        exit();
    } else {
        $error = "Failed to delete profile.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f7f7f7;
        }
        .container {
            display: flex;
            gap: 30px;
            width: 70%;
            margin: auto;
            padding: 20px 0;
        }
        .left, .right {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        .left {
            flex: 1;
        }
        .right {
            flex: 2;
        }
        h2 {
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        label {
            display: block;
            margin-top: 15px;
        }
        input, select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background: lightsalmon;
            border: none;
            color: white;
            cursor: pointer;
            transition: 0.2s;
            border-radius: 5px;
        }
        button:hover {
            transform: scale(1.1);
            opacity: 0.9;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
        .history-group {
            margin-top: 30px;
        }
        .purchase-history-wrapper {
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 8px;
            box-shadow: inset 0 0 5px #ccc;
        }
        .history-group table th {
            background: #f5f5f5;
        }
        .button-row {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
    </style>
    <script>
        function togglePasswordFields() {
            const isChecked = document.getElementById('changePasswordCheckbox').checked;
            document.getElementById('newPasswordFields').style.display = isChecked ? 'block' : 'none';
        }
    </script>
</head>
<body>

<div class="container">
    <div class="left">
        <h2>Profile</h2>
        <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

        <form name="profileForm" method="post">
            <label>Username:</label>
            <input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? $user['user_id']) ?>" required>

            <label>Gender:</label>
            <select name="gender" required>
                <option value="Male" <?= (($user['gender'] ?? '') === 'Male') ? 'selected' : '' ?>>Male</option>
                <option value="Female" <?= (($user['gender'] ?? '') === 'Female') ? 'selected' : '' ?>>Female</option>
                <option value="Other" <?= (($user['gender'] ?? '') === 'Other') ? 'selected' : '' ?>>Other</option>
            </select>

            <label>Phone:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? $user['phone']) ?>" required>

            <label>Shipping Address:</label>
            <input type="text" name="address" value="<?= htmlspecialchars($_POST['address'] ?? $user['shipping_address']) ?>" required>

            

            <label>Current Password (for confirmation):</label>
            <input type="password" name="current_password" required>
            
            
<div style="margin-top: 15px; font-size: 0.85em; display: flex; align-items: center; gap: 10px; width: 20%;">
    <label for="changePasswordCheckbox" style="margin: 0; width: 100px;">Change Password</label>
    <input type="checkbox" id="changePasswordCheckbox" name="change_password" onchange="togglePasswordFields()">
</div>


            <div id="newPasswordFields" style="display: none;">
                <label>New Password:</label>
                <input type="password" name="new_password">
            </div>
            
            <div class="button-row">
                <button type="submit" name="update">Update Profile</button>
            </div>
        </form>

        <form method="post" onsubmit="return confirm('Are you sure you want to delete your profile? This action cannot be undone.');">
            <button type="submit" name="delete_profile" style="background-color: red;">Delete Profile</button>
        </form>
    </div>

    <div class="right">
        <h2>Purchase History</h2>
        <div class="purchase-history-wrapper">
            <?php if (empty($history_data)): ?>
                <p>No Purchase History.</p>
            <?php else: ?>
                <?php foreach ($history_data as $history_id => $products): ?>
                    <div class="history-group">
                        <h3>History ID: <?= $history_id ?></h3>
                        <table>
                            <tr>
                                <th>Product Name</th>
                                <th>Quantity</th>
                                <th>Price (RM)</th>
                                <th>Subtotal (RM)</th>
                            </tr>
                            <?php foreach ($products as $item): ?>
                                <tr>
                                    <td><?= $item['product_name'] ?></td>
                                    <td><?= $item['history_product_quantity'] ?></td>
                                    <td><?= number_format($item['product_price'], 2) ?></td>
                                    <td><?= number_format($item['history_product_quantity'] * $item['product_price'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer><?php include 'footer.php'; ?></footer>
</body>
</html>
