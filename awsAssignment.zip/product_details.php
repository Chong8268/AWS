<?php
include 'header.php';
include 'db_connect.php';

if (!isset($_GET['id'])) {
    header("Location: shop.php");
    exit();
}

$product_id = $_GET['id'];

// Fetch product info
$stmt = $conn->prepare("SELECT * FROM products WHERE product_id = ?");
$stmt->bind_param("s", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Product not found.";
    exit();
}

$product = $result->fetch_assoc();

// Handle Add to Cart
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_to_cart'])) {
    if (!isset($_SESSION['user_id'])) {
        echo "<script>
            alert('You must login to add items to your cart.');
            window.location.href = 'login.php';
        </script>";
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $quantity = intval($_POST['quantity']);
    $cart_id = $user_id;

    if ($quantity <= 0 || $quantity > $product['quantity']) {
        echo "<script>alert('Invalid quantity selected.');</script>";
    } else {
        // Check if item already in cart
        $check = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
        $check->bind_param("ss", $user_id, $product_id);
        $check->execute();
        $existing = $check->get_result();

        if ($existing->num_rows === 0) {
            $insert = $conn->prepare("INSERT INTO cart (cart_id, user_id, product_id, cart_quantity) VALUES (?, ?, ?, ?)");
            $insert->bind_param("sssi", $cart_id, $user_id, $product_id, $quantity);
            $insert->execute();
        } else {
            $update = $conn->prepare("UPDATE cart SET cart_quantity = cart_quantity + ? WHERE user_id = ? AND product_id = ?");
            $update->bind_param("iss", $quantity, $user_id, $product_id);
            $update->execute();
        }

        echo "<script>alert('Product added to cart.'); window.location='shop.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($product['product_name']); ?> | The Cap Conner</title>
    <style>
        body {
            background-color: #f9f9f9;
            color: #333;
            line-height: 1.6;
        }

        .product-container {
            display: flex;
            width: 60%;
            margin: 60px auto;
            padding: 0 20px;
            gap: 50px;
            align-items: center;
        }

        .product-image {
            flex: 1;
            padding: 20px;
            background: white;
            box-shadow: 0 0 10px #ccc;
            border-radius: 10px;
            text-align: center;
        }

        .product-image img {
            max-width: 100%;
            height: 450px;
            object-fit: contain;
            border-radius: 5px;
        }

        .product-info {
            flex: 1;
            padding: 20px;
        }

        .product-title {
            font-size: 2.5rem;
            margin-bottom: 15px;
            font-weight: 500;
            letter-spacing: 1px;
            color: #333;
        }

        .product-price {
            font-size: 2rem;
            color: #e67e22;
            margin: 20px 0;
            font-weight: 500;
        }

        .stock-status {
            display: inline-block;
            padding: 5px 10px;
            background: #e8f5e9;
            color: #2e7d32;
            border-radius: 20px;
            font-size: 0.9rem;
            margin-bottom: 20px;
        }

        .divider {
            height: 1px;
            background: linear-gradient(to right, transparent, #ddd, transparent);
            margin: 25px 0;
        }

        .product-description {
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1rem;
            line-height: 1.8;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            margin: 30px 0;
        }

        .quantity-label {
            margin-right: 15px;
            font-size: 1.1rem;
        }

        .quantity-input {
            width: 70px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
            font-size: 1rem;
        }

        .add-to-cart-btn {
            background-color: lightsalmon;
            color: white;
            border: none;
            padding: 12px 30px;
            font-size: 1rem;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s;
            border-radius: 4px;
            margin-left: 15px;
            text-transform: uppercase;
        }

        .add-to-cart-btn:hover {
            background-color: #e97b5b;
        }

        .product-meta {
            margin-top: 30px;
            font-size: 0.9rem;
            color: #999;
        }

        @media (max-width: 768px) {
            .product-container {
                flex-direction: column;
                gap: 30px;
            }

            .product-image, .product-info {
                width: 100%;
            }

            .product-title {
                font-size: 2rem;
            }

            .quantity-selector {
                flex-direction: column;
                align-items: flex-start;
            }

            .add-to-cart-btn {
                margin: 15px 0 0 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="product-container">
    <div class="product-image">
        <img src="image/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>">
    </div>
    <div class="product-info">
        <h1 class="product-title"><?php echo htmlspecialchars($product['product_name']); ?></h1>
        <span class="stock-status"><b><?php echo $product['quantity']; ?></b> available in stock</span>
        <div class="product-price">RM <?php echo number_format($product['product_price'], 2); ?></div>
        <div class="divider"></div>
        <div class="product-description">
            <?php echo nl2br(htmlspecialchars($product['description'])); ?>
        </div>

        <form method="post">
            <div class="quantity-selector">
                <label class="quantity-label" for="quantity">Quantity:</label>
                <input type="number" class="quantity-input" id="quantity" name="quantity"
                       min="1" max="<?php echo $product['quantity']; ?>" value="1" required>
                <button type="submit" class="add-to-cart-btn" name="add_to_cart">Add to Cart</button>
            </div>
        </form>

        <div class="product-meta">
            <p><strong>Product Code:</strong> <?php echo htmlspecialchars($product['product_id']); ?></p>
            <p><strong>Category:</strong> <?php echo htmlspecialchars($product['category_id'] ?? 'Uncategorized'); ?></p>
        </div>
    </div>
</div>

<footer><?php include 'footer.php'; ?></footer>

</body>
</html>
