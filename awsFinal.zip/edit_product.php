<?php
include 'header.php';
include 'db_connect.php';

$id = $_GET['id'];
$product = $conn->query("SELECT * FROM products WHERE product_id = '$id'")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['product_name'];
    $price = $_POST['product_price'];
    $quantity = $_POST['quantity'];
    $category = $_POST['category_id'];
    $desc = $_POST['description'];

    // Check if image was updated
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "image/" . $image);
        $conn->query("UPDATE products SET image='$image' WHERE product_id='$id'");
    }

    $stmt = $conn->prepare("UPDATE products SET product_name=?, product_price=?, quantity=?, category_id=?, description=? WHERE product_id=?");
    $stmt->bind_param("sdisss", $name, $price, $quantity, $category, $desc, $id);
    $stmt->execute();

    header("Location: admin_page.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link rel="stylesheet" href="admin_styles.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<h2>Edit Product</h2>
<form method="post" enctype="multipart/form-data">
    <div>
        <label>Name:</label>
        <input type="text" name="product_name" value="<?= $product['product_name'] ?>" required class="form-control">
    </div>

    <div>
        <label>Price:</label>
        <input type="number" step="0.01" name="product_price" value="<?= $product['product_price'] ?>" required class="form-control">
    </div>

    <div>
        <label>Quantity:</label>
        <input type="number" name="quantity" value="<?= $product['quantity'] ?>" required class="form-control">
    </div>

    <div>
        <label>Category:</label>
        <select name="category_id" class="form-control">
            <?php foreach (['graduation cap', 'graduation hood', 'graduation set', 'other'] as $cat): ?>
                <option value="<?= $cat ?>" <?= ($product['category_id'] == $cat) ? 'selected' : '' ?>>
                    <?= ucfirst($cat) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <label>Description:</label>
        <textarea name="description" class="form-control"><?= $product['description'] ?></textarea>
    </div>

    <div>
        <label>Current Image:</label><br>
        <img src="image/<?= $product['image'] ?>" width="100" style="margin-bottom:10px;"><br>
        <label>Change Image:</label>
        <input type="file" name="image" class="form-control">
    </div>

    <div class="add-btn">
        <button class="btn btn-primary">Update Product</button>
    </div>
</form>

<?php include 'footer.php'; ?>
</body>
</html>
