<?php include 'header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Terms and Conditions | The Cap Conner</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
        }

        .terms-container {
            max-width: 800px;
            margin: auto;
            margin-top: 30px;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: lightsalmon;
        }

        h2 {
            margin-top: 25px;
            color: #444;
        }

        p {
            line-height: 1.6;
        }

        a {
            color: lightsalmon;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            font-size: 14px;
            color: #777;
        }
    </style>
</head>
<body>

<div class="terms-container">
    <h1>Terms and Conditions</h1>

    <p>Welcome to The Cap Conner! By accessing or using our website, you agree to comply with and be bound by the following terms and conditions. Please read them carefully.</p>

    <h2>1. Use of Website</h2>
    <p>You may use our website for lawful purposes only. You agree not to misuse or disrupt the service.</p>

    <h2>2. Account Responsibility</h2>
    <p>You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>

    <h2>3. Privacy</h2>
    <p>We value your privacy. Please review our <a href="https://www.termsfeed.com/live/337949fe-b433-4aee-8876-509d98f1ce25">Privacy Policy</a> to understand how we handle your data.</p>

    <h2>4. Modifications</h2>
    <p>We reserve the right to modify these terms at any time. Changes will be posted here, and your continued use of the site indicates acceptance.</p>

    <h2>5. Contact</h2>
    <p>If you have any questions about these terms, please contact us at <a href="mailto:support@capconner.com">support@capconner.com</a>.</p>


</div>
    </body
    <footer>
        <?php include './footer.php'; ?>
    </footer>

</html>
