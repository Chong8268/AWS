<?php
include 'header.php';
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    $user_id = trim($_POST["username"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE user_id = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $user_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['gender'] = $row['gender'];
        $_SESSION['phone'] = $row['phone'];
        $_SESSION['address'] = $row['shipping_address']; // changed to shipping_address
        $_SESSION['password'] = $row['password'];
        $_SESSION['role'] = $row['role']; // Add this line

        // Redirect based on role
        if ($row['role'] == 1) {
            header("Location: index.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login | The Cap Conner</title>
    <style>
        body {
            overflow: hidden;
            margin: 0;
            padding: 0;
        }

        .container {
            display: flex;
            height: 100vh;
        }

        .left-half {
            flex: 1;
        }

        .left-half img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: opacity 1s ease-in-out;
        }

        .right-half {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f9f9f9;
        }

        .login-form {
            width: 80%;
            max-width: 400px;
            padding: 30px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .login-form h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .login-form input {
            width: 94%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-form button {
            width: 100%;
            padding: 10px;
            background-color: lightsalmon;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.2s;
        }

        .login-form button:hover {
            background-color: #e97b5b;
        }
    </style>
</head>
<body>



<div class="container">
    <div class="left-half">
        <img id="slideshow" src="image/graduate7.jpg" alt="Slideshow" />
    </div>
    <div class="right-half">
        <form class="login-form" method="post" action="login.php">
            <h2>Login</h2>
            <input type="text" name="username" placeholder="Username" required />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit" name="login">Login</button>
            <?php if (!empty($error)) echo "<p style='color:red; text-align:center;'>$error</p>"; ?>
            <p style="text-align: center; font-size: 14px; margin-top: 15px;">
                New user? <a href="signup.php" style="color: lightsalmon; text-decoration: none;">Sign Up</a>
            </p>
        </form>
    </div>
</div>

<script>
    const images = [
        "image/graduate1.jpg",
        "image/graduate2.jpg",
        "image/graduate3.jpg",
        "image/graduate7.jpg"
    ];
    let index = 0;
    const slideshow = document.getElementById("slideshow");

    setInterval(() => {
        index = (index + 1) % images.length;
        slideshow.style.opacity = 0;
        setTimeout(() => {
            slideshow.src = images[index];
            slideshow.style.opacity = 1;
        }, 500);
    }, 4000);
</script>

</body>
</html>
