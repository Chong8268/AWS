<!DOCTYPE html>

<html>
    <head></head>
    <body>
<footer style="background-color: #000; color: #fff; text-align: center; font-size: 14px; padding: 15px 0; position: relative; bottom: 0; width: 100%;">
    <p style="margin: 0;">
        &copy; <?php echo date("Y"); ?> The Cap Conner &nbsp;|&nbsp;
        <a href="term.php" style="text-decoration: none; color: #fff;">Terms & Conditions</a> &nbsp;|&nbsp;
        <a href="https://www.termsfeed.com/live/337949fe-b433-4aee-8876-509d98f1ce25" style="text-decoration: none; color: #fff;">Privacy Policy</a>
    </p>
</footer>




    </body>
</html>
